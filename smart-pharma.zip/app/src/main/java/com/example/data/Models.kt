package com.example.data

import java.util.Date

data class Medicine(
    val id: String,
    val tradeName: String,     // الاسم التجاري
    val scientificName: String, // الاسم العلمي
    val quantity: Int,          // الكمية المتوفرة
    val price: Double,          // سعر البيع (بالدولار أو الدينار العراقي)
    val buyPrice: Double,       // سعر الشراء
    val category: String,       // فئة الدواء (أقراص، شراب، إلخ)
    val barcode: String = "",   // الباركود
    val expiryDate: String = "",// تاريخ انتهاء الصلاحية
    val minRequiredQty: Int = 10, // الحد الأدنى لتنبيه نقص المخزون
    val internalBarcode: String = "",
    val qrCode: String = "",
    val strength: String = "",
    val dosageForm: String = "",
    val categoryId: String = "",
    val companyId: String = "",
    val country: String = "",
    val batchNumber: String = "",
    val productionDate: String = "",
    val salePrice: Double = price,
    val purchasePrice: Double = buyPrice,
    val minimumSalePrice: Double = price,
    val lastPurchasePrice: Double = buyPrice,
    val lastSalePrice: Double = price,
    val profit: Double = price - buyPrice,
    val reservedQuantity: Int = 0,
    val unit: String = "العلبة", // الحبة، الشريط، العلبة، الكارتون
    val conversionFactor: Int = 1,
    val location: String = "",
    val image: String = "",
    val description: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val createdBy: String = ""
)

data class Category(
    val id: String = "",
    val name: String = "",
    val color: String = "#2196F3", // اللون بالهكس
    val icon: String = "Category", // اسم الأيقونة أو المعرف
    val description: String = ""
)

data class Company(
    val id: String = "",
    val name: String = "",
    val country: String = "", // بلد المنشأ
    val logo: String = "" // شعار الشركة اختياري (Base64 أو رابط)
)

data class StockMovement(
    val id: String = "",
    val medicineId: String = "",
    val medicineTradeName: String = "",
    val type: String = "", // إضافة، تعديل، حذف، بيع، شراء، إرجاع، تغيير سعر، تعديل كمية
    val quantity: Int = 0,
    val user: String = "",
    val dateTime: Long = System.currentTimeMillis(),
    val notes: String = ""
)

data class ExpiredMedicine(
    val id: String = "",
    val medicineId: String = "",
    val tradeName: String = "",
    val quantity: Int = 0,
    val expiryDate: String = "",
    val reportedAt: Long = System.currentTimeMillis(),
    val reportedBy: String = ""
)

data class BarcodeHistoryItem(
    val id: String = "",
    val barcode: String = "",
    val medicineId: String = "",
    val tradeName: String = "",
    val scannedAt: Long = System.currentTimeMillis(),
    val scannedBy: String = ""
)

data class SaleItem(
    val medicineId: String,
    val tradeName: String,
    val quantity: Int,
    val price: Double,
    val unit: String = "العلبة",
    val discount: Double = 0.0
)

data class Sale(
    val id: String,
    val date: Date,
    val items: List<SaleItem>,
    val totalAmount: Double,
    val totalCost: Double,
    val customerName: String = "زبون عام",
    val discount: Double = 0.0,
    val paymentMethod: String = "نقداً", // نقداً، آجل، تحويل مصرفي، متعدد
    val employeeName: String = "",
    val pharmacyName: String = "",
    val status: String = "Completed", // Completed, Voided
    val voidReason: String = "",
    val voidBy: String = "",
    val qrCodeData: String = ""
) {
    val profit: Double
        get() = if (status == "Voided") 0.0 else (totalAmount - totalCost)
}

enum class UserRole {
    ADMIN,            // مدير النظام
    PHARMACY_MANAGER, // مدير الصيدلية
    EMPLOYEE,         // موظف
    ACCOUNTANT        // محاسب
}

data class User(
    val userId: String = "",
    val username: String = "",
    val passwordHash: String = "",
    val fullName: String = "",
    val role: UserRole = UserRole.EMPLOYEE,
    val clientId: String = "client001",
    val active: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val lastLogin: Long = 0L,
    val phone: String = "",
    val notes: String = "",
    val pharmacyName: String = "",
    val subscriptionStart: String = "",
    val subscriptionEnd: String = "",
    val allowedDevices: Int = 1,
    val status: String = "Active",
    val registeredDevices: List<String> = emptyList()
)

data class LogEntry(
    val id: String = "",
    val username: String = "",
    val dateTime: Long = System.currentTimeMillis(),
    val dateStr: String = "",
    val timeStr: String = "",
    val operationType: String = "",
    val details: String = ""
)

