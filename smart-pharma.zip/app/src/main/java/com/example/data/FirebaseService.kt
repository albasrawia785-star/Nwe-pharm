package com.example.data

import android.content.Context
import android.util.Log
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.security.MessageDigest

class FirebaseService(private val context: Context) {
    private val client = OkHttpClient()
    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    // استخراج رابط قاعدة البيانات من ملف الإعدادات
    val databaseUrl: String by lazy {
        try {
            val configContent = context.assets.open("firebase-config.js").bufferedReader().use { it.readText() }
            val match = Regex("""databaseURL\s*:\s*["']([^"']+)["']""").find(configContent)
            val url = match?.groupValues?.get(1) ?: "https://smart-pharma-warehouse-default-rtdb.firebaseio.com"
            url.trimEnd('/')
        } catch (e: Exception) {
            Log.e("FirebaseService", "Error reading firebase-config.js, using default", e)
            "https://smart-pharma-warehouse-default-rtdb.firebaseio.com"
        }
    }

    // تشفير كلمة المرور باستخدام SHA-256
    fun hashPassword(password: String): String {
        return try {
            val bytes = password.toByteArray()
            val md = MessageDigest.getInstance("SHA-256")
            val digest = md.digest(bytes)
            digest.fold("") { str, it -> str + "%02x".format(it) }
        } catch (e: Exception) {
            Log.e("FirebaseService", "Hashing failed, using fallback", e)
            password // fallback
        }
    }

    // جلب البيانات من مسار معين بشكل متزامن داخلياً (يجب استدعاؤه على Dispatchers.IO)
    private fun <T> getRaw(path: String, type: java.lang.reflect.Type): T? {
        val url = "$databaseUrl/$path.json"
        val request = Request.Builder().url(url).build()
        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val bodyString = response.body?.string() ?: return null
                if (bodyString == "null" || bodyString.trim().isEmpty()) return null
                val adapter = moshi.adapter<T>(type)
                return adapter.fromJson(bodyString)
            }
        } catch (e: Exception) {
            Log.e("FirebaseService", "GET failed for path: $path", e)
            return null
        }
    }

    // جلب البيانات بشكل غير متزامن باستخدام Coroutines
    suspend fun <T> get(path: String, type: java.lang.reflect.Type): T? = withContext(Dispatchers.IO) {
        getRaw(path, type)
    }

    // وضع البيانات في مسار معين بشكل متزامن داخلياً (PUT)
    private fun <T> putRaw(path: String, data: T, type: java.lang.reflect.Type): Boolean {
        val url = "$databaseUrl/$path.json"
        val adapter = moshi.adapter<T>(type)
        val json = adapter.toJson(data)
        val body = json.toRequestBody(jsonMediaType)
        val request = Request.Builder().url(url).put(body).build()
        try {
            client.newCall(request).execute().use { response ->
                return response.isSuccessful
            }
        } catch (e: Exception) {
            Log.e("FirebaseService", "PUT failed for path: $path", e)
            return false
        }
    }

    // وضع البيانات بشكل غير متزامن باستخدام Coroutines
    suspend fun <T> put(path: String, data: T, type: java.lang.reflect.Type): Boolean = withContext(Dispatchers.IO) {
        putRaw(path, data, type)
    }

    // حذف البيانات من مسار معين באופן غير متزامن
    suspend fun delete(path: String): Boolean = withContext(Dispatchers.IO) {
        val url = "$databaseUrl/$path.json"
        val request = Request.Builder().url(url).delete().build()
        try {
            client.newCall(request).execute().use { response ->
                response.isSuccessful
            }
        } catch (e: Exception) {
            Log.e("FirebaseService", "DELETE failed for path: $path", e)
            false
        }
    }

    // بذر البيانات الافتراضية إذا كانت قاعدة البيانات فارغة تماماً
    suspend fun seedDatabaseIfNeeded() = withContext(Dispatchers.IO) {
        // التحقق من وجود مستخدم المدير العام "ali"
        val adminPath = "users/ali"
        val existingAdmin: User? = getRaw(adminPath, User::class.java)
        
        if (existingAdmin == null) {
            Log.d("FirebaseService", "Admin user 'ali' not found. Seeding default data...")
            
            // 1. بذر حساب المدير العام
            val superAdmin = User(
                userId = "usr_superadmin",
                username = "ali",
                passwordHash = hashPassword("ali"),
                fullName = "المدير العام",
                role = UserRole.ADMIN,
                clientId = "client001",
                active = true,
                status = "Active",
                phone = "07700000000",
                notes = "حساب المدير العام الرئيسي (غير قابل للحذف أو التعطيل)",
                pharmacyName = "الإدارة العامة",
                subscriptionStart = "2026-01-01",
                subscriptionEnd = "2036-12-31",
                allowedDevices = 99999,
                registeredDevices = emptyList()
            )
            putRaw(adminPath, superAdmin, User::class.java)

            // 2. بذر المستخدمين التجريبيين الآخرين
            val usersType = Types.newParameterizedType(Map::class.java, String::class.java, User::class.java)
            val defaultUsers = mapOf(
                "pharmacy001" to User(
                    userId = "usr_002",
                    username = "pharmacy001",
                    passwordHash = hashPassword("pharm123"),
                    fullName = "د. علي أحمد",
                    role = UserRole.PHARMACY_MANAGER,
                    clientId = "client001",
                    active = true,
                    status = "Active",
                    phone = "07801234567",
                    notes = "مدير صيدلية فرع الكرادة",
                    pharmacyName = "صيدلية الكرادة الذكية",
                    subscriptionStart = "2026-01-01",
                    subscriptionEnd = "2027-12-31",
                    allowedDevices = 3,
                    registeredDevices = emptyList()
                ),
                "employee001" to User(
                    userId = "usr_003",
                    username = "employee001",
                    passwordHash = hashPassword("emp123"),
                    fullName = "أحمد محمد",
                    role = UserRole.EMPLOYEE,
                    clientId = "client001",
                    active = true,
                    status = "Active",
                    phone = "07901234567",
                    notes = "موظف مبيعات المساء",
                    pharmacyName = "صيدلية الكرادة الذكية",
                    subscriptionStart = "2026-01-01",
                    subscriptionEnd = "2027-12-31",
                    allowedDevices = 2,
                    registeredDevices = emptyList()
                ),
                "accountant001" to User(
                    userId = "usr_004",
                    username = "accountant001",
                    passwordHash = hashPassword("acc123"),
                    fullName = "هدى جاسم",
                    role = UserRole.ACCOUNTANT,
                    clientId = "client001",
                    active = true,
                    status = "Active",
                    phone = "07501234567",
                    notes = "المحاسب المالي للفرع",
                    pharmacyName = "صيدلية الكرادة الذكية",
                    subscriptionStart = "2026-01-01",
                    subscriptionEnd = "2027-12-31",
                    allowedDevices = 2,
                    registeredDevices = emptyList()
                )
            )
            
            for ((key, value) in defaultUsers) {
                putRaw("users/$key", value, User::class.java)
            }
            
            Log.d("FirebaseService", "Default licensing accounts seeded successfully!")
        }
    }
}
