package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.PharmaViewModel
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            // التحقق من الوضع الداكن الافتراضي للنظام
            val systemDark = isSystemInDarkTheme()
            var isDarkTheme by remember { mutableStateOf(systemDark) }

            MyApplicationTheme(darkTheme = isDarkTheme) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val pharmaViewModel: PharmaViewModel = viewModel()
                    val navController = rememberNavController()
                    val currentUser by pharmaViewModel.currentUser.collectAsState()

                    // مراقبة تسجيل الخروج أو تسجيل الدخول لإعادة توجيه المسارات تلقائياً
                    LaunchedEffect(currentUser) {
                        if (currentUser == null) {
                            navController.navigate("login") {
                                popUpTo(0) { inclusive = true }
                            }
                        } else {
                            navController.navigate("dashboard") {
                                popUpTo("login") { inclusive = true }
                            }
                        }
                    }

                    NavHost(
                        navController = navController,
                        startDestination = "login"
                    ) {
                        // شاشة تسجيل الدخول
                        composable("login") {
                            LoginScreen(
                                viewModel = pharmaViewModel,
                                onLoginSuccess = {
                                    // سيتم نقله للوحة التحكم عبر الـ LaunchedEffect
                                }
                            )
                        }

                        // لوحة التحكم الأساسية
                        composable("dashboard") {
                            DashboardScreen(
                                viewModel = pharmaViewModel,
                                onNavigateToSales = { navController.navigate("sales") },
                                onNavigateToPOS = { navController.navigate("pos") },
                                onNavigateToInventory = { navController.navigate("inventory") },
                                onNavigateToReports = { navController.navigate("reports") },
                                onNavigateToSettings = { navController.navigate("settings") },
                                onNavigateToUsersManagement = { navController.navigate("users_management") },
                                onNavigateToCategoriesCompanies = { navController.navigate("categories_companies") },
                                onNavigateToStockMovements = { navController.navigate("stock_movements") },
                                onLogout = { pharmaViewModel.logout() }
                            )
                        }

                        // نقطة البيع الاحترافية (POS)
                        composable("pos") {
                            POSScreen(
                                viewModel = pharmaViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        // مستودع الأدوية
                        composable("inventory") {
                            InventoryScreen(
                                viewModel = pharmaViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        // فاتورة المبيعات
                        composable("sales") {
                            SalesScreen(
                                viewModel = pharmaViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        // التقارير الحسابية وسجل الفواتير
                        composable("reports") {
                            ReportsScreen(
                                viewModel = pharmaViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        // الإعدادات العامة للمظهر والعملة
                        composable("settings") {
                            SettingsScreen(
                                viewModel = pharmaViewModel,
                                isDarkTheme = isDarkTheme,
                                onToggleTheme = { isDarkTheme = it },
                                onNavigateBack = { navController.popBackStack() },
                                onLogout = { pharmaViewModel.logout() }
                            )
                        }

                        // لوحة إدارة المستخدمين (خاص بمدير النظام)
                        composable("users_management") {
                            UsersManagementScreen(
                                viewModel = pharmaViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        // إدارة التصنيفات والشركات المصنعة
                        composable("categories_companies") {
                            CategoriesCompaniesScreen(
                                viewModel = pharmaViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        // سجل حركة المخزن
                        composable("stock_movements") {
                            StockMovementsScreen(
                                viewModel = pharmaViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
