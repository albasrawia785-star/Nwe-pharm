package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.User
import com.example.data.UserRole
import com.example.ui.PharmaViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UsersManagementScreen(
    viewModel: PharmaViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val users by viewModel.usersList.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    
    // حالات إدارة الدايلوج
    var showUserDialog by remember { mutableStateOf(false) }
    var selectedUser by remember { mutableStateOf<User?>(null) } // null يعني إضافة جديد
    
    // حقول إدخال المستخدم الجديد / المعدل
    var inputUsername by remember { mutableStateOf("") }
    var inputFullName by remember { mutableStateOf("") }
    var inputPassword by remember { mutableStateOf("") }
    var inputRole by remember { mutableStateOf(UserRole.EMPLOYEE) }
    var inputClientId by remember { mutableStateOf("client001") }
    var inputPhone by remember { mutableStateOf("") }
    var inputNotes by remember { mutableStateOf("") }
    var inputActive by remember { mutableStateOf(true) }
    
    var inputPharmacyName by remember { mutableStateOf("") }
    var inputStatus by remember { mutableStateOf("Active") }
    var inputSubscriptionStart by remember { mutableStateOf("") }
    var inputSubscriptionEnd by remember { mutableStateOf("") }
    var inputAllowedDevices by remember { mutableStateOf(1) }
    var registeredDevicesList by remember { mutableStateOf<List<String>>(emptyList()) }

    // لتحديث الحقول عند اختيار مستخدم للتعديل
    LaunchedEffect(selectedUser) {
        if (selectedUser != null) {
            inputUsername = selectedUser!!.username
            inputFullName = selectedUser!!.fullName
            inputPassword = "" // إبقاء كلمة المرور فارغة لعدم التغيير الافتراضي
            inputRole = selectedUser!!.role
            inputClientId = selectedUser!!.clientId
            inputPhone = selectedUser!!.phone
            inputNotes = selectedUser!!.notes
            inputActive = selectedUser!!.active
            
            inputPharmacyName = selectedUser!!.pharmacyName
            inputStatus = selectedUser!!.status
            inputSubscriptionStart = selectedUser!!.subscriptionStart
            inputSubscriptionEnd = selectedUser!!.subscriptionEnd
            inputAllowedDevices = selectedUser!!.allowedDevices
            registeredDevicesList = selectedUser!!.registeredDevices
        } else {
            // تصفير القيم للإضافة الجديدة
            inputUsername = ""
            inputFullName = ""
            inputPassword = ""
            inputRole = UserRole.EMPLOYEE
            inputClientId = "client001"
            inputPhone = ""
            inputNotes = ""
            inputActive = true
            
            inputPharmacyName = ""
            inputStatus = "Active"
            
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val cal = Calendar.getInstance()
            inputSubscriptionStart = sdf.format(cal.time)
            cal.add(Calendar.YEAR, 1)
            inputSubscriptionEnd = sdf.format(cal.time)
            
            inputAllowedDevices = 1
            registeredDevicesList = emptyList()
        }
    }

    // جلب البيانات عند فتح الشاشة
    LaunchedEffect(Unit) {
        viewModel.fetchAllUsers()
    }

    // تصفية المستخدمين بناءً على حقل البحث
    val filteredUsers = users.filter {
        it.fullName.contains(searchQuery, ignoreCase = true) ||
        it.username.contains(searchQuery, ignoreCase = true) ||
        it.phone.contains(searchQuery, ignoreCase = true) ||
        it.pharmacyName.contains(searchQuery, ignoreCase = true)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "نظام إدارة التراخيص والمستخدمين",
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Right
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    selectedUser = null
                    showUserDialog = true
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add User")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // شريط البحث
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("بحث عن مستخدم بالاسم، الصيدلية أو الهاتف...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary
                )
            )

            if (isLoading && filteredUsers.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                }
            } else if (filteredUsers.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Group,
                            contentDescription = "No users",
                            tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.3f),
                            modifier = Modifier.size(72.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            "لم يتم العثور على أي مستخدمين أو تراخيص",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredUsers) { user ->
                        UserListItem(
                            user = user,
                            onEditClick = {
                                selectedUser = user
                                showUserDialog = true
                            },
                            onToggleActive = { active ->
                                viewModel.toggleUserActive(user.username, active) { success ->
                                    if (success) {
                                        Toast.makeText(context, "تم تعديل حالة الحساب بنجاح", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            onDeleteClick = {
                                viewModel.deleteUser(user.username) { success ->
                                    if (success) {
                                        Toast.makeText(context, "تم حذف المستخدم من Firebase", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "خطأ في حذف المستخدم", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            onResetDevices = {
                                val updated = user.copy(registeredDevices = emptyList())
                                viewModel.saveUser(updated, null) { success ->
                                    if (success) {
                                        Toast.makeText(context, "تم إعادة تعيين الأجهزة المسجلة بنجاح", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "فشل تعيين الأجهزة", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    // دايلوج إضافة وتعديل المستخدم
    if (showUserDialog) {
        AlertDialog(
            onDismissRequest = { showUserDialog = false },
            title = {
                Text(
                    text = if (selectedUser == null) "إضافة مستخدم جديد وترخيص" else "تعديل بيانات المستخدم والترخيص",
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Right
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // حقل اسم المستخدم (معرف الدخول فريد ومكتوب باللغة الإنجليزية)
                    OutlinedTextField(
                        value = inputUsername,
                        onValueChange = { inputUsername = it },
                        label = { Text("اسم المستخدم (معرّف فريد بالإنكليزية)") },
                        enabled = selectedUser == null, // لا يمكن تغيير الـ username بعد إنشائه في Firebase
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // الاسم الكامل للمستخدم
                    OutlinedTextField(
                        value = inputFullName,
                        onValueChange = { inputFullName = it },
                        label = { Text("الاسم الكامل باللغة العربية") },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // اسم الصيدلية المخصصة
                    OutlinedTextField(
                        value = inputPharmacyName,
                        onValueChange = { inputPharmacyName = it },
                        label = { Text("اسم الصيدلية") },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // كلمة المرور
                    OutlinedTextField(
                        value = inputPassword,
                        onValueChange = { inputPassword = it },
                        label = { 
                            Text(
                                if (selectedUser == null) "كلمة المرور" 
                                else "كلمة المرور الجديدة (اتركها فارغة للإبقاء على القديمة)"
                            ) 
                        },
                        placeholder = { Text(if (selectedUser == null) "أدخل كلمة المرور" else "اختياري") },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // رقم الهاتف للاتصال والتواصل
                    OutlinedTextField(
                        value = inputPhone,
                        onValueChange = { inputPhone = it },
                        label = { Text("رقم الهاتف") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // عزل البيانات: معرّف العميل المخصص لهذه الصيدلية
                    OutlinedTextField(
                        value = inputClientId,
                        onValueChange = { inputClientId = it },
                        label = { Text("معرّف العميل (عزل البيانات: client001, etc.)") },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // حالة الترخيص والاشتراك
                    Text(
                        "حالة الترخيص والاشتراك:",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Right
                    )
                    
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { inputStatus = "Active" }
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Text("نشط ومفعل (Active)")
                            RadioButton(
                                selected = inputStatus == "Active",
                                onClick = { inputStatus = "Active" }
                            )
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { inputStatus = "Suspended" }
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Text("موقوف مؤقتاً (Suspended)")
                            RadioButton(
                                selected = inputStatus == "Suspended",
                                onClick = { inputStatus = "Suspended" }
                            )
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { inputStatus = "Expired" }
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Text("منتهي الصلاحية (Expired)")
                            RadioButton(
                                selected = inputStatus == "Expired",
                                onClick = { inputStatus = "Expired" }
                            )
                        }
                    }

                    // تاريخ بدء وانتهاء الاشتراك
                    OutlinedTextField(
                        value = inputSubscriptionStart,
                        onValueChange = { inputSubscriptionStart = it },
                        label = { Text("تاريخ بدء الاشتراك (yyyy-MM-dd)") },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = inputSubscriptionEnd,
                        onValueChange = { inputSubscriptionEnd = it },
                        label = { Text("تاريخ انتهاء الاشتراك (yyyy-MM-dd)") },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // عدد الأجهزة المسموح بها
                    OutlinedTextField(
                        value = inputAllowedDevices.toString(),
                        onValueChange = { 
                            inputAllowedDevices = it.toIntOrNull() ?: 1 
                        },
                        label = { Text("الحد الأقصى للأجهزة المسموحة (0 أو 9999 يعني غير محدود)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // تعيين الصلاحية والمسؤوليات
                    Text(
                        "الصلاحية ومستوى الوصول:",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Right
                    )

                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { inputRole = UserRole.ADMIN }
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Text("مدير النظام (ADMIN)")
                            RadioButton(
                                selected = inputRole == UserRole.ADMIN,
                                onClick = { inputRole = UserRole.ADMIN }
                            )
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { inputRole = UserRole.PHARMACY_MANAGER }
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Text("مدير صيدلية (PHARMACY_MANAGER)")
                            RadioButton(
                                selected = inputRole == UserRole.PHARMACY_MANAGER,
                                onClick = { inputRole = UserRole.PHARMACY_MANAGER }
                            )
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { inputRole = UserRole.EMPLOYEE }
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Text("موظف صيدلية (EMPLOYEE)")
                            RadioButton(
                                selected = inputRole == UserRole.EMPLOYEE,
                                onClick = { inputRole = UserRole.EMPLOYEE }
                            )
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { inputRole = UserRole.ACCOUNTANT }
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Text("محاسب مالي (ACCOUNTANT)")
                            RadioButton(
                                selected = inputRole == UserRole.ACCOUNTANT,
                                onClick = { inputRole = UserRole.ACCOUNTANT }
                            )
                        }
                    }

                    // تفعيل الحساب أو إيقافه
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Switch(
                            checked = inputActive,
                            onCheckedChange = { inputActive = it }
                        )
                        Text(
                            text = "تفعيل الحساب (يسمح بالولوج للنظام)",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }

                    // ملاحظات إضافية عن الموظف
                    OutlinedTextField(
                        value = inputNotes,
                        onValueChange = { inputNotes = it },
                        label = { Text("ملاحظات إضافية") },
                        maxLines = 3,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (inputUsername.isBlank() || inputFullName.isBlank()) {
                            Toast.makeText(context, "يرجى تعبئة الحقول الأساسية", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        
                        val u = User(
                            userId = selectedUser?.userId ?: "",
                            username = inputUsername,
                            fullName = inputFullName,
                            role = inputRole,
                            clientId = inputClientId,
                            active = inputActive,
                            phone = inputPhone,
                            notes = inputNotes,
                            pharmacyName = inputPharmacyName,
                            status = inputStatus,
                            subscriptionStart = inputSubscriptionStart,
                            subscriptionEnd = inputSubscriptionEnd,
                            allowedDevices = inputAllowedDevices,
                            registeredDevices = registeredDevicesList
                        )
                        
                        viewModel.saveUser(u, inputPassword.takeIf { it.isNotBlank() }) { success ->
                            if (success) {
                                Toast.makeText(context, "تم حفظ بيانات المستخدم والترخيص بنجاح", Toast.LENGTH_SHORT).show()
                                showUserDialog = false
                            } else {
                                Toast.makeText(context, "خطأ في عملية الحفظ: اسم المستخدم 'ali' الرئيسي أو مكرر", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("حفظ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showUserDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
fun UserListItem(
    user: User,
    onEditClick: () -> Unit,
    onToggleActive: (Boolean) -> Unit,
    onDeleteClick: () -> Unit,
    onResetDevices: () -> Unit
) {
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showResetDevicesConfirm by remember { mutableStateOf(false) }

    val roleName = when (user.role) {
        UserRole.ADMIN -> "مدير النظام العام"
        UserRole.PHARMACY_MANAGER -> "مدير صيدلية"
        UserRole.EMPLOYEE -> "موظف مبيعات"
        UserRole.ACCOUNTANT -> "محاسب مالي"
    }

    val roleColor = when (user.role) {
        UserRole.ADMIN -> MaterialTheme.colorScheme.error
        UserRole.PHARMACY_MANAGER -> MaterialTheme.colorScheme.primary
        UserRole.EMPLOYEE -> MaterialTheme.colorScheme.secondary
        UserRole.ACCOUNTANT -> MaterialTheme.colorScheme.tertiary
    }

    val loginDateStr = if (user.lastLogin > 0L) {
        val date = Date(user.lastLogin)
        val format = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        format.format(date)
    } else {
        "لم يسجل دخول بعد"
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (user.active && user.status == "Active") MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // الصف العلوي (الاسم والتبديل للحالة النشطة)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // تفعيل/تعطيل
                Switch(
                    checked = user.active,
                    onCheckedChange = onToggleActive,
                    thumbContent = if (user.active) {
                        { Icon(Icons.Default.Check, null, modifier = Modifier.size(12.dp)) }
                    } else null
                )

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = user.fullName,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        textAlign = TextAlign.Right
                    )
                    Text(
                        text = "@${user.username}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                        textAlign = TextAlign.Right
                    )
                }
            }

            HorizontalDivider(
                modifier = Modifier.padding(vertical = 12.dp),
                color = MaterialTheme.colorScheme.outlineVariant
            )

            // تفاصيل الصلاحية ومعرف العميل والاتصال والاشتراكات
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (user.pharmacyName.isNotBlank()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = user.pharmacyName,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "اسم الصيدلية:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val statusText = when (user.status) {
                        "Active" -> "نشط"
                        "Suspended" -> "موقوف مؤقتاً"
                        "Expired" -> "منتهي الاشتراك"
                        "Deleted" -> "محذوف"
                        else -> user.status
                    }
                    val statusColor = when (user.status) {
                        "Active" -> Color(0xFF4CAF50)
                        "Suspended" -> Color(0xFFFF9800)
                        "Expired" -> Color(0xFFE91E63)
                        else -> MaterialTheme.colorScheme.onBackground
                    }
                    Text(
                        text = statusText,
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = statusColor)
                    )
                    Text(
                        text = "حالة الاشتراك والترخيص:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }

                if (user.subscriptionStart.isNotBlank() && user.subscriptionEnd.isNotBlank()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${user.subscriptionStart} إلى ${user.subscriptionEnd}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "فترة الاشتراك:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val allowedText = if (user.allowedDevices <= 0 || user.allowedDevices >= 9999) "غير محدود" else user.allowedDevices.toString()
                    Text(
                        text = "${user.registeredDevices.size} جهاز مسجل / $allowedText مسموح",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "الأجهزة النشطة:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // شارة الصلاحية الملونة
                    SuggestionChip(
                        onClick = {},
                        label = { Text(roleName, fontWeight = FontWeight.Bold, color = roleColor) },
                        colors = SuggestionChipDefaults.suggestionChipColors(
                            containerColor = roleColor.copy(alpha = 0.12f)
                        )
                    )
                    
                    Text(
                        text = "الصلاحية:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = user.clientId,
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "معرّف العميل (Tenant ID):",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }

                if (user.phone.isNotBlank()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = user.phone,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "الهاتف:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = loginDateStr,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "آخر تسجيل دخول:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }

                if (user.notes.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "ملاحظات: ${user.notes}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // صف أزرار التحكم والعمليات (تعديل وحذف وإعادة تعيين الأجهزة)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // زر حذف العضو
                // لا نسمح للمدير بحذف نفسه منعاً للقفل
                if (user.username != "ali" && user.username != "admin") {
                    OutlinedButton(
                        onClick = { showDeleteConfirm = true },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text("حذف", fontSize = 11.sp)
                    }
                }

                // زر إعادة تعيين الأجهزة
                if (user.registeredDevices.isNotEmpty()) {
                    OutlinedButton(
                        onClick = { showResetDevicesConfirm = true },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.tertiary),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reset", modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text("الأجهزة", fontSize = 11.sp)
                    }
                }

                // زر التعديل
                Button(
                    onClick = onEditClick,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(2.dp))
                    Text("تعديل", fontSize = 11.sp)
                }
            }
        }
    }

    // تأكيد الحذف
    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = {
                Text(
                    "حذف المستخدم السحابي؟",
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Right
                )
            },
            text = {
                Text(
                    "هل أنت متأكد من رغبتك في حذف الحساب ${user.fullName} بشكل دائم ونهائي من قاعدة بيانات Firebase؟ هذا الإجراء لا يمكن التراجع عنه.",
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Right
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDeleteClick()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("نعم، احذف")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // تأكيد تصفير الأجهزة
    if (showResetDevicesConfirm) {
        AlertDialog(
            onDismissRequest = { showResetDevicesConfirm = false },
            title = {
                Text(
                    "إعادة تعيين أجهزة المستخدم؟",
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Right
                )
            },
            text = {
                Text(
                    "هل ترغب في مسح الأجهزة المسجلة للمستخدم ${user.fullName}؟ سيسمح له هذا بتسجيل الدخول مجدداً من أجهزة جديدة إذا تجاوز الحد المسموح.",
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Right
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showResetDevicesConfirm = false
                        onResetDevices()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("نعم، تصفير")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDevicesConfirm = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
