package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.UserRole
import com.example.ui.PharmaViewModel
import java.text.SimpleDateFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: PharmaViewModel,
    onNavigateToSales: () -> Unit,
    onNavigateToPOS: () -> Unit,
    onNavigateToInventory: () -> Unit,
    onNavigateToReports: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToUsersManagement: () -> Unit,
    onNavigateToCategoriesCompanies: () -> Unit,
    onNavigateToStockMovements: () -> Unit,
    onLogout: () -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val medicines by viewModel.medicines.collectAsState()
    val sales by viewModel.sales.collectAsState()

    // حساب الإحصائيات الحية من Firebase
    val totalMedicines = medicines.size
    val totalStockUnits = medicines.sumOf { it.quantity }
    val outOfStockItems = medicines.count { it.quantity == 0 }
    val lowStockItems = medicines.count { it.quantity > 0 && it.quantity <= it.minRequiredQty }

    // مبيعات وأرباح اليوم
    val todaySales = sales.filter { 
        android.text.format.DateUtils.isToday(it.date.time)
    }
    val todayRevenue = todaySales.sumOf { it.totalAmount }
    val todayProfit = todaySales.sumOf { it.profit }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                        Text(
                            text = "لوحة التحكم السحابية",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onLogout) {
                        Icon(
                            imageVector = Icons.Default.ExitToApp,
                            contentDescription = "Logout",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp),
            horizontalAlignment = Alignment.End
        ) {
            // كارت الترحيب ومستوى الوصول
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // معلومات العميل (عزل البيانات التام)
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
                            modifier = Modifier.padding(4.dp)
                        ) {
                            Text(
                                text = "العميل: ${currentUser?.clientId ?: "N/A"}",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                ),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }

                        Text(
                            text = "مرحباً بك، ${currentUser?.fullName ?: currentUser?.username ?: "المستخدم"}",
                            style = MaterialTheme.typography.titleLarge.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    val roleAr = when (currentUser?.role) {
                        UserRole.ADMIN -> "مدير النظام العام"
                        UserRole.PHARMACY_MANAGER -> "مدير صيدلية"
                        UserRole.EMPLOYEE -> "موظف صيدلية"
                        UserRole.ACCOUNTANT -> "محاسب مالي"
                        else -> "مستخدم"
                    }
                    Text(
                        text = "مستوى الوصول: $roleAr",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    )
                }
            }

            // حساب الأدوية منتهية الصلاحية قريباً (خلال 90 يوماً)
            val expiringSoonItems = medicines.count { med ->
                if (med.expiryDate.isBlank()) return@count false
                try {
                    val format = if (med.expiryDate.contains("-")) {
                        if (med.expiryDate.length > 7) SimpleDateFormat("yyyy-MM-dd", Locale.US)
                        else SimpleDateFormat("yyyy-MM", Locale.US)
                    } else {
                        return@count false
                    }
                    val expiry = format.parse(med.expiryDate) ?: return@count false
                    val diff = expiry.time - System.currentTimeMillis()
                    val diffDays = diff / (1000 * 60 * 60 * 24)
                    diffDays in 0..90
                } catch (e: Exception) {
                    false
                }
            }

            // بنر التنبيهات الحرجة والمخزون
            if (outOfStockItems > 0 || lowStockItems > 0 || expiringSoonItems > 0) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.9f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .clickable { onNavigateToInventory() }
                        .testTag("dashboard_alerts_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Alert",
                            tint = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.size(24.dp)
                        )
                        Column(
                            modifier = Modifier.weight(1f),
                            horizontalAlignment = Alignment.End
                        ) {
                            Text(
                                text = "تنبيهات المخزن الحرجة",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            val alertText = buildString {
                                if (outOfStockItems > 0) append("• $outOfStockItems نافذ ")
                                if (lowStockItems > 0) append("• $lowStockItems مخزون حرج ")
                                if (expiringSoonItems > 0) append("• $expiringSoonItems ينتهي قريباً ")
                            }
                            Text(
                                text = alertText,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.8f),
                                textAlign = TextAlign.Right
                            )
                        }
                    }
                }
            }

            Text(
                text = "الإحصائيات المزامنة سحابياً",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(bottom = 8.dp)
            )

            // شبكة الإحصائيات الكبرى والعمليات المتوفرة بحسب الصلاحيات
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                // إجمالي الأدوية بالمستودع
                item {
                    StatCard(
                        title = "أنواع الأدوية",
                        value = "$totalMedicines دواء",
                        icon = Icons.Default.MedicalServices,
                        color = MaterialTheme.colorScheme.secondary,
                        subtitle = "إجمالي الوحدات: $totalStockUnits"
                    )
                }

                // مبيعات اليوم
                item {
                    StatCard(
                        title = "مبيعات اليوم",
                        value = "$${String.format("%.2f", todayRevenue)}",
                        icon = Icons.Default.MonetizationOn,
                        color = MaterialTheme.colorScheme.primary,
                        subtitle = "عدد الفواتير: ${todaySales.size}"
                    )
                }

                // الأرباح اليومية (متاحة للمدير المالي والمدير العام فقط)
                if (currentUser?.role == UserRole.ADMIN || currentUser?.role == UserRole.ACCOUNTANT || currentUser?.role == UserRole.PHARMACY_MANAGER) {
                    item {
                        StatCard(
                            title = "أرباح اليوم",
                            value = "$${String.format("%.2f", todayProfit)}",
                            icon = Icons.Default.TrendingUp,
                            color = MaterialTheme.colorScheme.tertiary,
                            subtitle = "هامش صافي الربح"
                        )
                    }
                }

                // التنبيهات ونقص المخزون
                item {
                    val badgeColor = if (lowStockItems > 0 || outOfStockItems > 0 || expiringSoonItems > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outline
                    StatCard(
                        title = "نواقص المخزون",
                        value = "${lowStockItems + outOfStockItems + expiringSoonItems} أدوية",
                        icon = Icons.Default.Warning,
                        color = badgeColor,
                        subtitle = "نفذ تماماً: $outOfStockItems",
                        onClick = onNavigateToInventory
                    )
                }

                // اختصارات العمليات والوصول المقيد بالصلاحيات
                
                // 1. فاتورة مبيعات (متاحة للجميع عدا المحاسب المالي المجرّد)
                if (currentUser?.role != UserRole.ACCOUNTANT) {
                    item {
                        QuickActionCard(
                            title = "فاتورة بيع جديدة",
                            subtitle = "سجل مبيعات فورية",
                            icon = Icons.Default.AddShoppingCart,
                            onClick = onNavigateToSales,
                            color = MaterialTheme.colorScheme.primaryContainer
                        )
                    }
                }

                // 1.1. نقطة بيع POS احترافية (متاحة للجميع عدا المحاسب)
                if (currentUser?.role != UserRole.ACCOUNTANT) {
                    item {
                        QuickActionCard(
                            title = "نقطة البيع (POS)",
                            subtitle = "نظام بيع تجاري متكامل",
                            icon = Icons.Default.ReceiptLong,
                            onClick = onNavigateToPOS,
                            color = MaterialTheme.colorScheme.primaryContainer
                        )
                    }
                }

                // 2. إدارة المستودع (متاحة للجميع للرؤية، وللتعديل بحسب الصلاحيات)
                item {
                    QuickActionCard(
                        title = "إدارة المستودع",
                        subtitle = "تحديث الأدوية والكميات",
                        icon = Icons.Default.Inventory,
                        onClick = onNavigateToInventory,
                        color = MaterialTheme.colorScheme.secondaryContainer
                    )
                }

                // 3. إدارة التصنيفات والشركات الطبية
                item {
                    QuickActionCard(
                        title = "التصنيفات والشركات",
                        subtitle = "تنظيم الأدوية ومورديها",
                        icon = Icons.Default.Category,
                        onClick = onNavigateToCategoriesCompanies,
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                    )
                }

                // 4. سجل حركات المخزن التفصيلي
                item {
                    QuickActionCard(
                        title = "سجل حركة المخزن",
                        subtitle = "تتبع عمليات الإدخال والبيع",
                        icon = Icons.Default.History,
                        onClick = onNavigateToStockMovements,
                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                    )
                }

                // 5. التقارير الحسابية (للمدير، المحاسب، ومدير الصيدلية)
                if (currentUser?.role == UserRole.ADMIN || currentUser?.role == UserRole.ACCOUNTANT || currentUser?.role == UserRole.PHARMACY_MANAGER) {
                    item {
                        QuickActionCard(
                            title = "التقارير الحسابية",
                            subtitle = "تحليلات الأرباح والمخزون",
                            icon = Icons.Default.Assessment,
                            onClick = onNavigateToReports,
                            color = MaterialTheme.colorScheme.tertiaryContainer
                        )
                    }
                }

                // 6. لوحة إدارة المستخدمين (خاص لمدير النظام حصراً ADMIN)
                if (currentUser?.role == UserRole.ADMIN) {
                    item {
                        QuickActionCard(
                            title = "إدارة المستخدمين",
                            subtitle = "الحسابات والصلاحيات سحابياً",
                            icon = Icons.Default.Group,
                            onClick = onNavigateToUsersManagement,
                            color = MaterialTheme.colorScheme.errorContainer
                        )
                    }
                }

                // 7. الإعدادات العامة للمظهر
                item {
                    QuickActionCard(
                        title = "إعدادات المظهر",
                        subtitle = "تخصيص الواجهة والعملة",
                        icon = Icons.Default.Settings,
                        onClick = onNavigateToSettings,
                        color = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    subtitle: String,
    onClick: (() -> Unit)? = null
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
    ) {
        Column(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.End
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(28.dp)
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                        fontWeight = FontWeight.Medium
                    ),
                    overflow = TextOverflow.Ellipsis,
                    maxLines = 1
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun QuickActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    color: Color
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = color.copy(alpha = 0.8f)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .height(115.dp)
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.End
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                textAlign = TextAlign.Right,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                ),
                textAlign = TextAlign.Right,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
