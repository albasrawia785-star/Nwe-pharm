// ملف إعدادات Firebase لـ "مستودع الصيدلية الذكي"
// يمكنك استبدال الرابط أدناه برابط Realtime Database الخاص بك لتوصيل التطبيق بقاعدتك المباشرة
const firebaseConfig = {
  apiKey: "AIzaSyAg1pfc-CcxjPFLqzUeeoNaP9LvBlJhKgA",
  authDomain: "project-2633249655177112121.firebaseapp.com",
  databaseURL: "https://project-2633249655177112121-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "project-2633249655177112121",
  storageBucket: "project-2633249655177112121.firebasestorage.app",
  messagingSenderId: "929737360669",
  appId: "1:929737360669:web:55e332f798c9cd0e9a8df4",
  measurementId: "G-8XXN1ZH86G"
};
